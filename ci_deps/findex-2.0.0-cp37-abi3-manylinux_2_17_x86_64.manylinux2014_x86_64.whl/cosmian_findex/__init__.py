# -*- coding: utf-8 -*-
from .cosmian_findex import *

__doc__ = cosmian_findex.__doc__
if hasattr(cosmian_findex, '__all__'):
    __all__ = cosmian_findex.__all__
